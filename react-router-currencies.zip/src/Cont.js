import React, {Component} from 'react'
class Cont extends Component{
    render(){
        // console.log(this.props);
        return(
            <div>It works! </div>
        )
    }
}
export default Cont