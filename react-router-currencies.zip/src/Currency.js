import React, {Component} from 'react'
import axios from 'axios'
const KEY = '24q5g54h4jw46j45wuy5hswjh6j4j6';
const URL = `https://data.fixer.io/api/latest?access_key=${KEY}`;
class Currency extends Component{
    constructor(){
        super();
        this.state = {rate: 0};
    }
    render(){
        let code = this.props.match.params.code;
        var rate;
        var _this = this;
        axios.get(URL)
        .then(function(response){
            rate = response.data.rates[code.toUpperCase()];
            _this.setState({rate: rate});
            //_this - cu bara jos ca sa folosim this
          //  console.log(response.data.rates[code.toUpperCase()]);
        });
        // console.log(this.props);
        return(
            <div>Info for {code} : {this.state.rate}</div>
            // <div>Info for {this.props.match.params.code} </div>
        )
    }
}
export default Currency