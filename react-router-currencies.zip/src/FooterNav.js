import React, {Component} from 'react'
import {BrowserRouter as Router,Link, Route} from 'react-router-dom'
import Term from './Term'
import Cont from './Cont'

class FooterNav extends Component{
    render(){
        return (
            <Router>
         <nav>
             <Link to="/currency/eur">Cont</Link>  
             <br/>     
             <Link to="/currency/usd">Term</Link>  
         </nav>
         <hr/>
         {/* <Currency/> */}
         <Route path="/currency/:code" component={Currency}/> 
         {/* <Route path="/currency/usd" exact component={Currency}/>
         <Route path="/currency/gbp" exact component={Currency}/> */}
         </Router>
        )
    }
}
export default FooterNav 