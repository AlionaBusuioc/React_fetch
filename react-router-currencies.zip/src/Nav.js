import React, {Component} from 'react'
import {BrowserRouter as Router,Link, Route} from 'react-router-dom'
import Currency from './Currency'

class Nav extends Component{
    render(){
        return (
            <Router>
         <nav>
             <Link to="/currency/eur">EURO</Link>  
             <br/>     
             <Link to="/currency/usd">USD</Link>  
             <br/>
             <Link to="/currency/gbp">GBP</Link>     
         </nav>
         <hr/>
         {/* <Currency/> */}
         <Route path="/currency/:code" component={Currency}/> 
         {/* <Route path="/currency/usd" exact component={Currency}/>
         <Route path="/currency/gbp" exact component={Currency}/> */}
         </Router>
        )
    }
}
export default Nav 