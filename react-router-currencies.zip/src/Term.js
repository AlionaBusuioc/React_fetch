import React, {Component} from 'react'
class Term extends Component{
    render(){
        // console.log(this.props);
        return(
            <div>It works! </div>
        )
    }
}
export default Term